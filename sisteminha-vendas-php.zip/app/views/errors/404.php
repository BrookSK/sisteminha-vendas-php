<div class="container py-5">
  <div class="text-center">
    <h1 class="display-5">404</h1>
    <p class="lead">Página não encontrada</p>
    <p class="text-muted">A URL acessada não existe ou foi movida.</p>
    <a href="/admin" class="btn btn-primary mt-2">Ir para o painel</a>
  </div>
</div>
